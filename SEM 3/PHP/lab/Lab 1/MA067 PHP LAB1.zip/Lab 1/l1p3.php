<?php
$name = "Jaymin Valaki";
$rollNumber = "123456";
$sem2SPI = "8.5";

echo "Name: " . $name . "<br>";
echo "Roll Number: " . $rollNumber . "<br>";
echo "Sem 2 SPI: " . $sem2SPI . "<br>";

?>
