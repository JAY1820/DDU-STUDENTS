<?php
function testScope() {
    $localVar = "I am a local variable";
    echo $localVar . "<br>";
}

testScope();
?>
