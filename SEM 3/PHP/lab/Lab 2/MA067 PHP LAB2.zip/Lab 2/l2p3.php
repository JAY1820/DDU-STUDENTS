<?php
$intVar = 10;
echo "Integer: " . $intVar . "<br>";

$floatVar = 3.14;
echo "Float: " . $floatVar . "<br>";

$stringVar = "Hello, PHP!";
echo "String: " . $stringVar . "<br>";

$boolVar = true;
echo "Boolean: " . $boolVar . "<br>";
?>
