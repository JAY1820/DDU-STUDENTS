<?php
$var1 = 10;
$var2 = 5;

echo "Equal to: " . ($var1 == $var2) . "<br>";
echo "Not equal to: " . ($var1 != $var2) . "<br>";
echo "Greater than: " . ($var1 > $var2) . "<br>";
echo "Less than: " . ($var1 < $var2) . "<br>";
echo "Greater than or equal to: " . ($var1 >= $var2) . "<br>";
echo "Less than or equal to: " . ($var1 <= $var2) . "<br>";
?>
