<?php
$var1 = 10;
$var2 = 20;

echo "Variable 1: " . $var1 . "<br>";
echo "Variable 2: " . $var2 . "<br>";
?>
