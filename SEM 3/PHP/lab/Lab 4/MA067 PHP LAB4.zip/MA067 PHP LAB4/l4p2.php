<!-- Create a php script which passes the array into function as a parameter. The
function then counts the total number of odd, even and prime numbers -->

<?php
function countOddEvenPrime($array) {
    $odd = 0;
    $even = 0;
    $prime = 0;
    foreach ($array as $value) {
        if ($value % 2 == 0) {
            $even++;
        } else {
            $odd++;
        }
        if ($value == 1) {
            $prime++;
        } else {
            for ($i = 2; $i < $value; $i++) {
                if ($value % $i == 0) {
                    $prime++;
                    break;
                }
            }
        }
    }
    echo "Odd: $odd<br>";
    echo "Even: $even<br>";
    echo "Prime: $prime<br>";
}