<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
 <title>Student result</title>
 <style> 
 input{
  width: 100%;
 }
 </style>
</head>
<body>
 <form method="POST" name ="frm" action="l5p3data.php">
 <table align="center">
 <tr>
  <th>Sum No</th>
 </tr>
 <tr>
  <td><input type="text" placeholder="Enter 10 no" name="no" required></td>
 </tr>
 <tr>
  <td><input type="Submit" name="sbt" value="Submit"></td>
 </tr>
 </table>
 </form>
</body> 
</html> 
