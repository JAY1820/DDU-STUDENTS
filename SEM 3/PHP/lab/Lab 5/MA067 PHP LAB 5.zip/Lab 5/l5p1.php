<!doctype html>
<html>
 <head>
 <title>Registration Form</title>
 <style> 
input{
 width: 100%;
 }
 </style>
 </head>
<body>
 <form method="post" action="./l5p1data.php">
 <table>
 <tr>
 <th><h1>Registration Form</h1></th>
 </tr>
 <tr>
 <td><input type="text" name="name" placeholder="Enter username"></td>
 </tr>
 <tr>
 <td><input type="password" name="pass" placeholder="Enter password"></td>
 </tr>
 <tr>
 <td><input type="text" name="branch" placeholder="Enter branch"></td>
 </tr>
 <tr>
 <td><input type="text" name="contact" placeholder="Enter contact no"></td>
 </tr>
 <tr>
 <td><input type="submit" name="sbt" value="Register"></td>
 </tr>
 </table> 
</form>
</body> 
</html>
