<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
<form method="post" action="./l5p2data.php">
<label>Enter no 1: </label>
<input type="number" name='no1'/></br>
<label>Enter no 2: </label>
<input type="number" name='no2'/></br> </br>  <br>
<button name='add'>Addition</button>
<button name='sub'>Substraction</button>
<button name="mul">Multiply</button>
<button name="div">Division</button></br>
<tr>
	<td><input type="Submit" name="submit" value="Submint"/></td>
</tr>


    
</form>
</body>
</html>
<?php