<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $filename = $_POST['filename'];
    $content = $_POST['content'];

    if (isset($_POST['write'])) {
        // Open the file in append mode and write the content
        $file = fopen($filename, 'a');
        if ($file) {
            fwrite($file, $content . "\n");
            fclose($file);
            echo "Content has been written to the file.";
        } else {
            echo "Error opening the file for writing.";
        }
    } elseif (isset($_POST['read'])) {
        // Read the content from the file and display it
        if (file_exists($filename)) {
            $fileContent = file_get_contents($filename);
            echo "<h2>File Content:</h2>";
            echo "<pre>$fileContent</pre>";
        } else {
            echo "File not found.";
        }
    }
}
?>
