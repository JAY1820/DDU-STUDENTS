<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $examNo = $_POST['exam_no'];
    $course = $_POST['course'];
    $semester = $_POST['semester'];
    
    $photoFile = $_FILES['photo'];
    $photoName = $photoFile['name'];
    $photoSize = $photoFile['size'];
    $photoTmpName = $photoFile['tmp_name'];
    
    if ($photoSize > 25600) { // 25KB in bytes
        echo "Error: Photo size exceeds 25KB.";
        exit();
    }
    
    if (!move_uploaded_file($photoTmpName, "photos/$photoName")) {
        echo "Error uploading photo.";
        exit();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Student Result</title>
</head>
<body>
    <h1>Student Result</h1>
    <h2>Exam No: <?php echo $examNo; ?></h2>
    <p>Course: <?php echo $course; ?></p>
    <p>Semester: <?php echo $semester; ?></p>
    <img src="photos/<?php echo $photoName; ?>" alt="Student Photo"><br><br>
    
    <!-- You can also include the logic to input and calculate the student's marks here -->
    
    <a href="index.php">Back to Form</a>
</body>
</html>
