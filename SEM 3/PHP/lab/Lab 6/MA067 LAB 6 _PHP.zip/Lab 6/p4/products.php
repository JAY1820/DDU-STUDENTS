<?php
session_start();

$products = [
    'product1' => 10.00,
    'product2' => 20.00,
    'product3' => 30.00
];

if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['product'])) {
        $product = $_POST['product'];
        $quantity = $_POST['quantity'];
        
        $_SESSION['cart'][$product] = $quantity;
    }
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Products</title>
</head>
<body>
    <h1>Products</h1>
    <p>Welcome, <?php echo $_SESSION['username']; ?>! Select products to buy:</p>
    
    <form method="POST" action="">
        <?php foreach ($products as $product => $price) { ?>
            <label for="<?php echo $product; ?>">
                <?php echo $product; ?> - $<?php echo $price; ?>
                <input type="number" id="<?php echo $product; ?>" name="quantity" min="1" value="1">
                <input type="submit" name="product" value="<?php echo $product; ?>">
            </label>
            <br>
        <?php } ?>
    </form>
    
    <a href="cart.php">View Cart</a> | <a href="logout.php">Logout</a>
</body>
</html>
