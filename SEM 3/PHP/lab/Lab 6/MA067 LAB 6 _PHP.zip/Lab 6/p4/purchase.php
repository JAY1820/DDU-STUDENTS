<?php
session_start();

if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Purchase</title>
</head>
<body>
    <h1>Purchase</h1>
    <p>Welcome, <?php echo $_SESSION['username']; ?>! Your purchase is complete. Thank you!</p>
    
    <a href="products.php">Back to Products</a> | <a href="logout.php">Logout</a>
</body>
</html>
