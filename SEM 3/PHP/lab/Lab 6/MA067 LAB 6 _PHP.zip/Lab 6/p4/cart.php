<?php
session_start();

if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['buy'])) {
        $_SESSION['cart'] = array(); // Clear the cart after purchase
        header('Location: purchase.php');
        exit();
    }
}

$cartItems = $_SESSION['cart'] ?? array();
$products = [
    'product1' => 10.00,
    'product2' => 20.00,
    'product3' => 30.00
];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Cart</title>
</head>
<body>
    <h1>Cart</h1>
    <p>Welcome, <?php echo $_SESSION['username']; ?>! Your cart:</p>
    
    <table>
        <tr>
            <th>Product</th>
            <th>Quantity</th>
            <th>Price</th>
            <th>Total</th>
        </tr>
        <?php foreach ($cartItems as $product => $quantity) { ?>
            <tr>
                <td><?php echo $product; ?></td>
                <td><?php echo $quantity; ?></td>
                <td>$<?php echo $products[$product]; ?></td>
                <td>$<?php echo $products[$product] * $quantity; ?></td>
            </tr>
        <?php } ?>
    </table>
    
    <form method="POST" action="">
        <input type="submit" name="buy" value="Buy">
    </form>
    
    <a href="products.php">Back to Products</a> | <a href="logout.php">Logout</a>
</body>
</html>
