<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = md5($_POST['password']); // Encrypting the password with MD5 (not secure for production use)
    $hobbies = isset($_POST['hobbies']) ? $_POST['hobbies'] : array();

    $_SESSION['user_info'] = array(
        'username' => $username,
        'password' => $password,
        'hobbies' => $hobbies
    );

    header('Location: viewhobbies.php');
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Signup</title>
</head>
<body>
    <h1>Signup</h1>
    <form method="POST" action="">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required><br><br>
        
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required><br><br>
        
        <label>Hobbies:</label><br>
        <input type="checkbox" name="hobbies[]" value="Reading"> Reading<br>
        <input type="checkbox" name="hobbies[]" value="Gaming"> Gaming<br>
        <input type="checkbox" name="hobbies[]" value="Cooking"> Cooking<br>
        
        <input type="submit" value="Signup">
    </form>
</body>
</html>
