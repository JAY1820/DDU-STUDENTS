<?php
session_start();

if (isset($_SESSION['user_info'])) {
    $username = $_SESSION['user_info']['username'];
    $hobbies = $_SESSION['user_info']['hobbies'];
} else {
    echo "Login required";
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Hobbies</title>
</head>
<body>
    <h1>Welcome, <?php echo $username; ?></h1>
    <h2>Your Hobbies:</h2>
    <ul>
        <?php foreach ($hobbies as $hobby) {
            echo "<li>$hobby</li>";
        } ?>
    </ul>
</body>
</html>
